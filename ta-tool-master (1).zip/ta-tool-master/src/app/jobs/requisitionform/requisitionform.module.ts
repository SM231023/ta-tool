export class reqFormData{
    id:number=0;
    jobTitle:string='';
    serviceCatalog:string=''
    primary:string=' ';
    secondary:string=' ';
    designation:string=' ';
    organizationUnit:string=' ';
    gradeLevel:string=' ';
    functionalArea:string=' ';
    team:string=' ';
    client:string=' ';
    project:string=' ';
    vacancyCount:string=' ';
    raisedFDate:string=' ';
    raisedTDate:string=' ';
    requiredDate:string=' ';
    skills:string=' ';
    education:string=' ';
    jobDescription:string=' ';
    rolesResponsibilities:string=' ';
    jobLocation:string=' ';
    fileUpload:string=' ';
    contracttype:string=' ';
    currencyName:string='';
    EmploymentType:string=' ';
    NatureofVacancy:string=' ';
    vacancyType:string=' ';
    urgency:string='';

}