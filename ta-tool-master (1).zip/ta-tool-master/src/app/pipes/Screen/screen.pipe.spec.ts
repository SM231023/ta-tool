import { ScreenPipe } from './screen.pipe';

describe('ScreenPipe', () => {
  it('create an instance', () => {
    const pipe = new ScreenPipe();
    expect(pipe).toBeTruthy();
  });
});
